Do not re-sale or claim this as yours. 
you may edit the script as you feel fit

If you need help with the scrpit Go to "Raven Mods" on discord

command is "/tow" in chat
you can add basicly any flat bed tow truck and config the cars/trucks to sit perfectly on the trucks

If you need any help or want to check out our other stuff join our discord here! https://discord.gg/ZZK43qQeMt
